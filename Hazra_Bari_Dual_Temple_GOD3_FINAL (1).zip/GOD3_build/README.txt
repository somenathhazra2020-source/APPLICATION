Hazra Bari Dual Temple — GOD3
Main file: GOD3.py
Clean UI with no blank iframe audio boxes. Dual Maa Durga + Mahadev Shiva temple, strict IST puja schedule, and rolling upcoming festivals.
