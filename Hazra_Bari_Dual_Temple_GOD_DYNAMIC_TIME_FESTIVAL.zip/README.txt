HAZRA BARI DUAL TEMPLE — GOD.PY
Features: strict IST puja time gating, visible schedule, wrong-time refusal, night closure, dynamic Upcoming Festivals, Shardiya Navratri only as an Upcoming Festival from 11 Oct 2026, and rolling festival display including Karwa Chauth on 29 Oct 2026.
Deploy GOD.py as the Streamlit main file. Keep Supabase secrets in Streamlit Secrets.
