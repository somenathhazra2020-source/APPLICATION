# Hazra Bari Dual Temple — Streamlit deployment

## Files
- `1111.py` — app entrypoint
- `requirements.txt` — Python dependency

## Streamlit Cloud setup
1. Upload these files to the app's GitHub repository.
2. In Streamlit Community Cloud, set the app's **Main file path** to `1111.py`.
3. Open **App settings → Secrets** and add the following using your newly rotated API key (do not commit secrets to GitHub):

```toml
PANCHANG_API_URL = "https://api.navamsha.in/api/v1/panchang/full"
PANCHANG_API_KEY = "PASTE_YOUR_NEW_NAVAMSHA_API_KEY_HERE"
```

The app uses Durgapur coordinates and IST (UTC+5:30). The full Panchang endpoint supplies Tithi, Paksha, Nakshatra, Yoga, Karana and weekday. Sunrise/sunset and moonrise/moonset are requested from the dedicated timing endpoints. If a timing endpoint fails, its values remain blank; no Panchang value is substituted.

## Database note
This ZIP preserves the source app's existing SQLite database behavior (`mandir.db`). It does **not** migrate user/wallet/seva history to Neon/PostgreSQL. That migration is separate and should be done only after reviewing every database read/write path.
