HAZRA BARI DUAL TEMPLE — GOD2

Main Streamlit file: GOD2.py
Includes Maa Durga + Mahadev, strict IST puja-time gating, dynamic Upcoming Festivals,
Chadhawa/Bhog/Japa/Aarti/Darshan, existing dashboard/account/history/admin features,
and Shiva image/audio support.

Do not add pyswisseph/ephem dependencies. Configure Supabase secrets separately if used.
